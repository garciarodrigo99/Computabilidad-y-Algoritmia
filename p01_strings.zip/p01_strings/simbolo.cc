#include "simbolo.h"

#include <assert.h>

//https://stackoverflow.com/questions/22855860/initializing-const-char-in-constructor-will-there-be-a-memory-leak

Simbolo::Simbolo(std::string& param) : s_(param) {
  // std::cout << "String param: " << param << std::endl;
  // std::cout << "Simbolo: " << s_ << std::endl;
  assert(!(Simbolo::contieneCadenaVacia(*this))); //Infinito
  // for (int i = 0; i < simbolo_param.Size(); i++) {
  //   if (simbolo_param.position(i) == kCadenaVacia) {
  //     return true;
  //   }
  // }
}

Simbolo::~Simbolo(){}

// const char* Simbolo::GetSimbolo(){
//   return s_;
// }
    
// void Simbolo::SetSimbolo(char* param){
//   s_ = param;
// }

bool Simbolo::contieneCadenaVacia(Simbolo simbolo_param){
  for (int i = 0; i < simbolo_param.Size(); i++) {
    if (simbolo_param.position(i) == kCadenaVacia) {
      return true;
    }
  }
  return false;
}

int Simbolo::Size(){
  return s_.size();
}

const char Simbolo::position(int index){
  return s_[index];
}

std::ostream& operator<<(std::ostream& os, const Simbolo& param_simbolo){
  os << param_simbolo.s_;
  return os;
}